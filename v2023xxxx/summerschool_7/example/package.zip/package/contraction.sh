#!/bin/sh

#SBATCH --partition nv100-ins
#SBATCH --reservation user1_75
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=1
#SBATCH --mem 100G
#SBATCH --array=0-38
#SBATCH --job-name ConK
#SBATCH -o log/job.%j.out
#SBATCH --exclusive

export OMP_NUM_THREADS=18

i=$((1000*${SLURM_ARRAY_TASK_ID}+10000))

./contraction.exe $i

