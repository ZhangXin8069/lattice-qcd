#include "gamma.h"

FILE *fp = nullptr;

using namespace std;


struct param
{
	int ns;
	int nt;
};


class Prop: public vector<vector<vector<vector<vector<vector<vector<vector<complex<float>>>>>>>>>
{
public: 
	param pa;

	Prop() {;}

	void init(const param& _pa){
		pa = _pa;

		(*this).resize(pa.nt);
		for(int t=0; t<pa.nt; t++){
			(*this)[t].resize(pa.ns);
			for(int z=0; z<pa.ns; z++){
				(*this)[t][z].resize(pa.ns);
				for(int y=0; y<pa.ns; y++){
					(*this)[t][z][y].resize(pa.ns);	
					for(int x=0; x<pa.ns; x++){
						(*this)[t][z][y][x].resize(4);
						for(int is1=0; is1<4; is1++){
							(*this)[t][z][y][x][is1].resize(4);
							for(int is2=0; is2<4; is2++){
								(*this)[t][z][y][x][is1][is2].resize(3);
								for(int ic1=0; ic1<3; ic1++){
									(*this)[t][z][y][x][is1][is2][ic1].resize(3);
								}
							}
						}
					}
				}
			}
		}

		for(int t=0; t<pa.nt; t++)
        for(int z=0; z<pa.ns; z++)
        for(int y=0; y<pa.ns; y++)
        for(int x=0; x<pa.ns; x++)
        for(int is1=0; is1<4; is1++)
        for(int is2=0; is2<4; is2++)
        for(int ic1=0; ic1<3; ic1++)
        for(int ic2=0; ic2<3; ic2++)
            (*this)[t][z][y][x][is1][is2][ic1][ic2] = 0.0;
	}

	Prop(const param& _pa){
		init(_pa);
	}

	void operator=(const Prop& _prop){
        for(int t=0; t<pa.nt; t++)
        for(int z=0; z<pa.ns; z++)
        for(int y=0; y<pa.ns; y++)
        for(int x=0; x<pa.ns; x++)
		for(int is1=0; is1<4; is1++)
		for(int is2=0; is2<4; is2++)
		for(int ic1=0; ic1<3; ic1++)
		for(int ic2=0; ic2<3; ic2++)
            (*this)[t][z][y][x][is1][is2][ic1][ic2] = _prop[t][z][y][x][is1][is2][ic1][ic2];
    }

};


void readProp(Prop& prop, char* input){
	param pa = prop.pa;
	int dataByte = pa.ns*pa.ns*pa.ns*4*4*3*3*2*8;
	char* buff = (char *)malloc(dataByte);
	fp = fopen(input,"rb");

	for(int t=0; t<pa.nt; t++){
    	fread((char *)buff, 1, dataByte, fp);
		complex<double>* buf = (complex<double> *) buff;
		for(int z=0; z<pa.ns; z++)
    	for(int y=0; y<pa.ns; y++)
    	for(int x=0; x<pa.ns; x++)
    	for(int is1=0; is1<4; is1++)
    	for(int is2=0; is2<4; is2++)
    	for(int ic1=0; ic1<3; ic1++)
    	for(int ic2=0; ic2<3; ic2++){
			prop[t][z][y][x][is1][is2][ic1][ic2] = buf[0];
			buf += 1;
		}
		buf = nullptr;
	}

	fclose(fp);
	fp = nullptr;
	free(buff);
	buff = nullptr;
}


void levi3dContraction(complex<float> psi[3][3], complex<float> chi1[3][3], complex<float> chi2[3][3], int zeroFlag=true){
	if(zeroFlag)
		for(int i=0; i<3; i++)
		for(int j=0; j<3; j++)
			psi[i][j] = 0.0;

	for(int i=0; i<3; i++){
    	int i1 = (i+1)%3;
        int i2 = (i+2)%3;
        for(int j=0; j<3; j++){
        	int j1 = (j+1)%3;
            int j2 = (j+2)%3;
            psi[i][j] += chi1[i1][j1] * chi2[i2][j2];
            psi[i][j] -= chi1[i2][j1] * chi2[i1][j2];
            psi[i][j] -= chi1[i1][j2] * chi2[i2][j1];
            psi[i][j] += chi1[i2][j2] * chi2[i1][j1];
        }
    }
}


vector<complex<float>> contractLocalMeson(const Prop& prop, const param& pa, int prj){
	vector<complex<float>> twopt(pa.nt);
	vector<vector<complex<float>>> ga = gamma(prj);
	//vector<vector<complex<float>>> g5 = gamma(15);

	#pragma omp parallel for
	for(int t=0; t<pa.nt; t++){
		complex<float> Res(0.0, 0.0);
		for(int z=0; z<pa.ns; z++)
		for(int y=0; y<pa.ns; y++)
		for(int x=0; x<pa.ns; x++){

			complex<float> propA[4][4][3][3];
			for(int ic1=0; ic1<3; ic1++)
			for(int ic2=0; ic2<3; ic2++)
			for(int is1=0; is1<4; is1++)
			for(int is2=0; is2<4; is2++){
				propA[is1][is2][ic1][ic2] = conj(prop[t][z][y][x][is2][is1][ic2][ic1]);
				if((is1<2&&is2>=2) || (is1>=2&&is2<2)) propA[is1][is2][ic1][ic2] *= -1.0;
			}

			complex<float> tmp1[4][4][3][3];
			for(int ic1=0; ic1<3; ic1++)
			for(int ic2=0; ic2<3; ic2++)
			for(int is1=0; is1<4; is1++)
			for(int is2=0; is2<4; is2++)
			for(int is=0; is<4; is++)
				tmp1[is1][is2][ic1][ic2] += ga[is1][is] * propA[is][is2][ic1][ic2];

			complex<float> tmp2[4][4][3][3];
			for(int ic1=0; ic1<3; ic1++)
			for(int ic2=0; ic2<3; ic2++)
			for(int is1=0; is1<4; is1++)
			for(int is2=0; is2<4; is2++)
			for(int is=0; is<4; is++)
				tmp2[is1][is2][ic1][ic2] += tmp1[is1][is][ic1][ic2] * ga[is][is2];
			
			complex<float> res(0.0, 0.0);
			for(int ic1=0; ic1<3; ic1++)
			for(int ic2=0; ic2<3; ic2++)
			for(int is1=0; is1<4; is1++)
			for(int is2=0; is2<4; is2++)
				res += prop[t][z][y][x][is1][is2][ic1][ic2] * tmp2[is2][is1][ic2][ic1];
			
			Res += res;
		}
		twopt[t] = Res;
	}
		
	return twopt;
}


vector<complex<float>> contractLocalUnPoNucleon(const Prop& prop, const param& pa){
	vector<complex<float>> twopt(pa.nt);
	vector<vector<complex<float>>> cg5 = Cg5();
	vector<vector<complex<float>>> unpo = Tunpol();

	#pragma omp parallel for
	for(int t=0; t<pa.nt; t++){
		complex<float> Res(0.0, 0.0);
		for(int z=0; z<pa.ns; z++)
        for(int y=0; y<pa.ns; y++)
        for(int x=0; x<pa.ns; x++){
			
			complex<float> tmp11[4][4][3][3];
			for(int c11=0; c11<3; c11++)
			for(int c21=0; c21<3; c21++)
			for(int s11=0; s11<4; s11++)
			for(int s12=0; s12<4; s12++)
			for(int s21=0; s21<4; s21++){
				tmp11[s12][s21][c11][c21] += prop[t][z][y][x][s11][s21][c11][c21] * cg5[s11][s12];
			}

			complex<float> tmp12[4][4][3][3];
			for(int c12=0; c12<3; c12++)
            for(int c22=0; c22<3; c22++)
            for(int s12=0; s12<4; s12++)
            for(int s21=0; s21<4; s21++)
            for(int s22=0; s22<4; s22++){
				tmp12[s12][s21][c12][c22] += prop[t][z][y][x][s12][s22][c12][c22] * cg5[s21][s22];
			}

			complex<float> tmp13[3][3];
			for(int c13=0; c13<3; c13++)
			for(int c23=0; c23<3; c23++)
			for(int s13=0; s13<4; s13++)
			for(int s23=0; s23<4; s23++){
				tmp13[c13][c23] += prop[t][z][y][x][s13][s23][c13][c23] * unpo[s13][s23];
			}

			complex<float> tmp14[4][4][3][3];
			for(int s12=0; s12<4; s12++)
			for(int s21=0; s21<4; s21++){
				levi3dContraction(tmp14[s12][s21],tmp12[s12][s21],tmp13);
			}

			complex<float> res1(0.0, 0.0);
			for(int s12=0; s12<4; s12++)
			for(int s21=0; s21<4; s21++)
			for(int c11=0; c11<3; c11++)
			for(int c21=0; c21<3; c21++)
				res1 += tmp11[s12][s21][c11][c21] * tmp14[s12][s21][c11][c21];
			
			complex<float> tmp21[4][4][3][3];
            for(int c11=0; c11<3; c11++)
            for(int c23=0; c23<3; c23++)
            for(int s11=0; s11<4; s11++)
            for(int s12=0; s12<4; s12++)
            for(int s23=0; s23<4; s23++){
                tmp21[s12][s23][c11][c23] += prop[t][z][y][x][s11][s23][c11][c23] * cg5[s11][s12];
            }
			
			complex<float> tmp23[4][4][3][3];
			for(int c13=0; c13<3; c13++)
			for(int c21=0; c21<3; c21++)
			for(int s13=0; s13<4; s13++)
			for(int s21=0; s21<4; s21++)
			for(int s23=0; s23<4; s23++){
				tmp23[s23][s21][c13][c21] += prop[t][z][y][x][s13][s21][c13][c21] * unpo[s13][s23];	
			}

			complex<float> tmp24[4][4][3][3];
			for(int s12=0; s12<4; s12++)
			for(int s21=0; s21<4; s21++)
			for(int s23=0; s23<4; s23++){
				levi3dContraction(tmp24[s12][s23],tmp12[s12][s21],tmp23[s23][s21],false);
			}

			complex<float> res2(0.0, 0.0);
			for(int c11=0; c11<3; c11++)
            for(int c23=0; c23<3; c23++)
            for(int s12=0; s12<4; s12++)
            for(int s23=0; s23<4; s23++){
				res2 += tmp21[s12][s23][c11][c23] * tmp24[s12][s23][c11][c23];
			}

			Res += res1;
			Res += res2;
		}
		twopt[t] = Res;
	}

	return twopt;
}
