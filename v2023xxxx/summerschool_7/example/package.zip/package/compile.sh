rm contraction.exe
g++ -fopenmp contraction.cpp -o contraction.exe -w
