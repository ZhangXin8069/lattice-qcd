#ifndef GAMMA_H
#define GAMMA_H


#include <stdio.h>
#include <stdlib.h>
#include <vector>
#include <complex>


using namespace std;

vector<vector<complex<float>>> gamma(int gId){
    vector<vector<complex<float>>> ga;
    ga.resize(4);
    for(int i=0; i<4; i++){
        ga[i].resize(4);
    }

    for(int i=0; i<4; i++)
    for(int j=0; j<4; j++)
        ga[i][j] = 0.0;

    switch(gId){
        case 0:
        ga[0][0].real(1);
        ga[1][1].real(1);
        ga[2][2].real(1);
        ga[3][3].real(1);
        break;

        case 1:
        ga[0][3].imag(1);
        ga[1][2].imag(1);
        ga[2][1].imag(-1);
        ga[3][0].imag(-1);
        break;

        case 2:
        ga[0][3].real(-1);
        ga[1][2].real(1);
        ga[2][1].real(1);
        ga[3][0].real(-1);
        break;

        case 3:
        ga[0][0].imag(-1);
        ga[1][1].imag(1);
        ga[2][2].imag(-1);
        ga[3][3].imag(1);
        break;

        case 4:
        ga[0][2].imag(1);
        ga[1][3].imag(-1);
        ga[2][0].imag(-1);
        ga[3][1].imag(1);
        break;

        case 5:
        ga[0][1].real(-1);
        ga[1][0].real(1);
        ga[2][3].real(-1);
        ga[3][2].real(1);
        break;

        case 6:
        ga[0][1].imag(-1);
        ga[1][0].imag(-1);
        ga[2][3].imag(-1);
        ga[3][2].imag(-1);
        break;

        case 7:
        ga[0][2].real(1);
        ga[1][3].real(1);
        ga[2][0].real(-1);
        ga[3][1].real(-1);
        break;

        case 8:
        ga[0][2].real(1);
        ga[1][3].real(1);
        ga[2][0].real(1);
        ga[3][1].real(1);
        break;

        case 9:
        ga[0][1].imag(1);
        ga[1][0].imag(1);
        ga[2][3].imag(-1);
        ga[3][2].imag(-1);
        break;

        case 10:
        ga[0][1].real(-1);
        ga[1][0].real(1);
        ga[2][3].real(1);
        ga[3][2].real(-1);

        case 11:
        ga[0][2].imag(-1);
        ga[1][3].imag(1);
        ga[2][0].imag(-1);
        ga[3][1].imag(1);
        break;

        case 12:
        ga[0][0].imag(1);
        ga[1][1].imag(-1);
        ga[2][2].imag(-1);
        ga[3][3].imag(1);
        break;

        case 13:
        ga[0][3].real(-1);
        ga[1][2].real(1);
        ga[2][1].real(-1);
        ga[3][0].real(1);
        break;

        case 14:
        ga[0][3].imag(-1);
        ga[1][2].imag(-1);
        ga[2][1].imag(-1);
        ga[3][0].imag(-1);
        break;

        case 15:
        ga[0][0].real(1);
        ga[1][1].real(1);
        ga[2][2].real(-1);
        ga[3][3].real(-1);
        break;

        default:
        printf("gamma error\n");
        break;
    }

	return ga;
}


vector<vector<complex<float>>> Cg5(){
	return gamma(5);
}


vector<vector<complex<float>>> Tunpol(){
	vector<vector<complex<float>>> gI = gamma(0);
	vector<vector<complex<float>>> gt = gamma(8);

	vector<vector<complex<float>>> ga;
    ga.resize(4);
    for(int i=0; i<4; i++)
        ga[i].resize(4);

	for(int i=0; i<4; i++)
	for(int j=0; j<4; j++){
		ga[i][j] = (gI[i][j] + gt[i][j]);
		ga[i][j] *= 0.5;
	}

	return ga;
}


#endif
