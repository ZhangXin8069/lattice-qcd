#include "contraction.h"


int main(int count, char* arg[]){

    param pa;
    pa.ns = 24;
    pa.nt = 72;

	int confId = atoi(arg[1]);

    vector<int> tSrc;
    tSrc.push_back(0);
    tSrc.push_back(18);
    tSrc.push_back(36);
    tSrc.push_back(54);
    int nSrc = tSrc.size();

	vector<complex<float>> pionTwopt(pa.nt);
	vector<complex<float>> nucleonTwopt(pa.nt);

	char* fileName = "/public/home/zhangk/summerSchool/propagator/binary/beta6.20_mu-0.2770_ms-0.2400_L24x72_cfg_%d_hyp0_gfixed3.light.tsrc_%02d.dat";
	char input[500];
	

	Prop prop(pa);
	for(int tsrcId=0; tsrcId<tSrc.size(); tsrcId++){
		int tsrc = tSrc[tsrcId];
		sprintf(input, fileName, confId, tsrc);
		printf("read %s\n",input);
		readProp(prop, input);
		printf("read tsrc=%d, confId=%d, end\n",tsrc,confId);
		vector<complex<float>> pion2pt = contractLocalMeson(prop, pa, 15);
		vector<complex<float>> nucleon2pt = contractLocalUnPoNucleon(prop, pa);
		printf("calculate tsrc=%d, confId=%d, end\n",tsrc,confId);
		for(int tsnk=0; tsnk<pa.nt; tsnk++){
			int tSnk = (tsnk - tsrc + pa.nt) % pa.nt;
			pionTwopt[tSnk] += pion2pt[tsnk];
			nucleonTwopt[tSnk] += nucleon2pt[tsnk];
		}
	}

	for(int tsnk=0; tsnk<pa.nt; tsnk++){
		pionTwopt[tsnk] /= nSrc;
		nucleonTwopt[tsnk] /= nSrc;
	}

	char* pionName = "/public/home/user1/Kyon/twopt/twopt/source/pionTwopt_cfg%d.dat";
	char* nucleonName = "/public/home/user1/Kyon/twopt/twopt/source/nucleonTwopt_cfg%d.dat";
	char output[300];
	sprintf(output, pionName, confId);
	fp = fopen(output,"wb");
	fwrite((char*)(pionTwopt.data()), 1, pa.nt*2*4, fp);
	fclose(fp);
	sprintf(output, nucleonName, confId);
    fp = fopen(output,"wb");
    fwrite((char*)(nucleonTwopt.data()), 1, pa.nt*2*4, fp);
    fclose(fp);
	fp = nullptr;
	

    return 0;
}
